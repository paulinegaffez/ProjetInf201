
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

public class Hospi {

		private int numPatient;
		private int numHospi;
		private Date dateEntree;
		private Date dateSortie;
		private ArrayList<Hospi> listeHospi = new ArrayList<>();

		// Cr�ation des constructeurs
		
		public Hospi(int numHospi, int numPatient, Date dateEntree, Date dateSortie) {
			super();
			this.numHospi = numHospi;
			this.numPatient = numPatient;
			this.dateEntree = dateEntree;
			this.dateSortie = dateSortie;
		}
		
		public Hospi() {}
		
		/**
		 * @return the numHospi
		 */
		public int getNumHospi() {
			return numHospi;
		}
		/**
		 * @param numHospi the numHospi to set
		 */
		public void setNumHospi(int numHospi) {
			this.numHospi = numHospi;
		}
		/**
		 * @return the dateEntree
		 */
		public Date getDateEntree() {
			return dateEntree;
		}
		/**
		 * @param dateEntree the dateEntree to set
		 */
		public void setDateEntree(Date dateEntree) {
			this.dateEntree = dateEntree;
		}
		/**
		 * @return the dateSortie
		 */
		public Date getDateSortie() {
			return dateSortie;
		}
		/**
		 * @param dateSortie the dateSortie to set
		 */
		public void setDateSortie(Date dateSortie) {
			this.dateSortie = dateSortie;
		}
		/**
		 * @return the numPatient
		 */
		public int getNumPatient() {
			return numPatient;
		}
		/**
		 * @param numPatient the numPatient to set
		 */
		public void setNumPatient(int numPatient) {
			this.numPatient = numPatient;
		}

		/**
		 * @return the listeHospi
		 */
		public ArrayList<Hospi> getListeHospi() {
			return listeHospi;
		}
		/**
		 * @param listeHospi the listeHospi to set
		 */
		public void setListeHospi(ArrayList<Hospi> listeHospi) {
			this.listeHospi = listeHospi;
		}	
}
