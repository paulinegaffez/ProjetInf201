 import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class HospiDAO extends DAO<Hospi> {

    String url = "jdbc:mysql://localhost/projetInf201";
    String user = "root";
    String password = "";

    public boolean create(Hospi h) {
        return false;
      }

      public boolean delete(Hospi h) {
        return false;
      }       

      public boolean update(Hospi h) {
        return false;
      }
    
      
    // Permet de r�cup�rer les informations de la derni�re hospitalisation d'un patient le numPatient  
  
    public Hospi find(int numPatient) {
		Hospi hospi = new Hospi(); 
		
	try
    {
        Class.forName("com.mysql.jdbc.Driver").newInstance();
        Connection con = DriverManager.getConnection(url, user, password);
		
        PreparedStatement pstt = con.prepareStatement("SELECT NumPatient, NumHospitalisation, DateEntree, DateSortie FROM tab_hospitalisation WHERE NumPatient=? ORDER BY DateEntree DESC");
        pstt.setInt(1,numPatient);
        ResultSet res = pstt.executeQuery();
        if(res.first()) {
			hospi = new Hospi(res.getInt(1),res.getInt(2),res.getDate(3),res.getDate(4));
		}pstt.close();
		res.close();
		con.close();
		}
		catch (SQLException e) {
		      e.printStackTrace();
		    } catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return hospi;
	}   
	}

