import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

	public class Patient {
		private int numPatient;
		private String prenom;
		private String nom;
		private Date ddn;
		private int sexe;
		private ArrayList<Hospi> listeHospi = new ArrayList<>();
		
		// Cr�ation constructeurs
		public Patient(int numPatient, String prenom, String nom, Date ddn, int sexe) {
			super();
			this.numPatient = numPatient;
			this.prenom = prenom;
			this.nom = nom;
			this.ddn = ddn;
			this.sexe = sexe;
		}
		
		public Patient() {}
		
		/**
		 * @return the numPatient
		 */
		public int getNumPatient() {
			return numPatient;
		}
		/**
		 * @param numPatient the numPatient to set
		 */
		public void setNumPatient(int numPatient) {
			this.numPatient = numPatient;
		}
		/**
		 * @return the prenom
		 */
		public String getPrenom() {
			return prenom;
		}
		/**
		 * @param prenom the prenom to set
		 */
		public void setPrenom(String prenom) {
			this.prenom = prenom;
		}
		/**
		 * @return the nom
		 */
		public String getNom() {
			return nom;
		}
		/**
		 * @param nom the nom to set
		 */
		public void setNom(String nom) {
			this.nom = nom;
		}
		/**
		 * @return the ddn
		 */
		public Date getDdn() {
			return ddn;
		}
		/**
		 * @param ddn the ddn to set
		 */
		public void setDdn(Date ddn) {
			this.ddn = ddn;
		}
		/**
		 * @return the sexe
		 */
		public int getSexe() {
			return sexe;
		}
		/**
		 * @param sexe the sexe to set
		 */
		public void setSexe(int sexe) {
			this.sexe = sexe;
		}
		/**
		 * @return the listeHospi
		 */
		public ArrayList<Hospi> getListeHospi() {
			return listeHospi;
		}
		/**
		 * @param listeHospi the listeHospi to set
		 */
		public void setListeHospi(ArrayList<Hospi> listeHospi) {
			this.listeHospi = listeHospi;
		}

	// Cr�ation d'une m�thode toString()	
		public String toString() {
			
			String lesHospi="";
			Iterator<Hospi> it= getListeHospi().iterator();
			while(it.hasNext()) {
				lesHospi+= "n� "+ it.next().getNumPatient()+"\n" ;
			}
			return lesHospi;
			}
	}
