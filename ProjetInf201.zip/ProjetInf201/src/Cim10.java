public class Cim10 {
			private String codeCim10;
			private String libelleCim10;
			
			// Constructeur
			public Cim10() {}
			
			/**
			 * @return the codeCim10
			 */
			public String getCodeCim10() {
				return codeCim10;
			}
			/**
			 * @param codeCim10 the codeCim10 to set
			 */
			public void setCodeCim10(String codeCim10) {
				this.codeCim10 = codeCim10;
			}
			/**
			 * @return the libelleCim10
			 */
			public String getLibelleCim10() {
				return libelleCim10;
			}
			/**
			 * @param libelleCim10 the libelleCim10 to set
			 */
			public void setLibelleCim10(String libelleCim10) {
				this.libelleCim10 = libelleCim10;
			}
			
			public Cim10(String codeCim10, String libelleCim10) {
				super();
				this.codeCim10 = codeCim10;
				this.libelleCim10 = libelleCim10;
			}	
}
