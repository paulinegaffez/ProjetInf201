import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PatientDAO extends DAO<Patient> {

    String url = "jdbc:mysql://localhost/projetInf201";
    String user = "root";
    String password = "";

    public boolean create(Patient p) {
        return false;
      }

      public boolean delete(Patient p) {
        return false;
      }       

      public boolean update(Patient p) {
        return false;
      }
    
      
    //Permet de r�cup�rer les informations d'un patient avec son numPatient
      
 	public Patient find(int numPatient) {
		Patient patient = new Patient(); 
		
	try
    {
        Class.forName("com.mysql.jdbc.Driver").newInstance();
        Connection con = DriverManager.getConnection(url, user, password);
		
        PreparedStatement pstt = con.prepareStatement("SELECT NumPatient, Prenom, Nom, DateNaissance, Sexe FROM tab_patient WHERE NumPatient=?");
        pstt.setInt(1,numPatient);
        ResultSet res = pstt.executeQuery();
        if(res.first()) {
			patient = new Patient(res.getInt(1),res.getString(2),res.getString(3),res.getDate(4),res.getInt(5));
		}pstt.close();
		res.close();
		con.close();
		}
		catch (SQLException e) {
		      e.printStackTrace();
		    } catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return patient;
	}   
}
