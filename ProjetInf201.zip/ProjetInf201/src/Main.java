import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		// Initialisation du progamme
		Scanner sc = new Scanner(System.in);
		int x =0;
		char z =' ';
		int requete= 0;
	    String url = "jdbc:mysql://localhost/projetInf201";
	    String user = "root";
	    String password = "";
	    Patient patient = new Patient();
	    
// Tant que l'utilisateur r�pond oui, ce programme est lanc�
	    
do {   do { System.out.println("Merci de rentrer un num�ro de patient valide:");
		x = sc.nextInt();
		sc.nextLine();

	// Infos patient	
		DAO<Patient> p = new PatientDAO();
		patient = p.find(x);
		
		// V�rification de l'existence du numPatient et de la requ�te demand�e
		// et affichage info patient
		if(patient.getNumPatient()!=0) {		
			do {System.out.println("Merci de taper le chiffre correspondant � votre demande \n 1-La liste des hospitalisations d'un patient \n 2- La derni�re hospitalisation d'un patient et son diagnostic principal (si renseign�)");
				requete = sc.nextInt();
				sc.nextLine();
				if(requete!=1 & requete!=2) {System.out.println("Veuillez taper 1 ou 2");}
			}
			while(requete!=1 & requete!=2);
		System.out.println("Patient n�: "+patient.getNumPatient()+"\n Nom: "+patient.getNom()+"\n Prenom: "+patient.getPrenom()+"\n Date de naissance: "+patient.getDdn());
		}
		// Si le numPatient rentr� n'existe pas, le programme redemande un num�ro
		else {System.out.println("Le num�ro patient n'existe pas");

		}}while(patient.getNumPatient()==0);
		
	// Hospitalisations patient	
	switch(requete) {
		case 1 :
			// Permet de sortir la liste des hospitalisations du patient
	    	try
	        {
	       		Class.forName("com.mysql.jdbc.Driver").newInstance();
	            Connection con = DriverManager.getConnection(url, user, password);
	    						
	            PreparedStatement pstt = con.prepareStatement("SELECT NumPatient, NumHospitalisation, DateEntree, DateSortie FROM tab_hospitalisation WHERE NumPatient=?");
	            pstt.setInt(1,x);
	            ResultSet res = pstt.executeQuery();
	           
	            ArrayList<Hospi> listeHospi = new ArrayList<Hospi>(); 
	            patient.setListeHospi(listeHospi); 
	    	
	            while(res.next()) {
	    			Hospi hospi = new Hospi(res.getInt(1),res.getInt(2),res.getDate(3),res.getDate(4));
	    			patient.getListeHospi().add(hospi);
	    		}
	    		System.out.println("La liste des hospitalisations du patient est: \n"+patient.toString());
	    		
	    		pstt.close();
	    		res.close();
	    		con.close();
	    	}
	    		catch (SQLException e) {
	    		      e.printStackTrace();
	    		    } catch (InstantiationException e) {
	    			// TODO Auto-generated catch block
	    			e.printStackTrace();
	    		} catch (IllegalAccessException e) {
	    			// TODO Auto-generated catch block
	    			e.printStackTrace();
	    		} catch (ClassNotFoundException e) {
	    			// TODO Auto-generated catch block
	    			e.printStackTrace();
	    		}
	    	break;
	    	
		case 2 :
			// Permet de sortir la derni�re hospitalisation du patient
			// et le diagnostic principal s'il est renseign� � l'aide du DAO
			    
			DAO<Hospi> h = new HospiDAO();
			Hospi hospi = h.find(x);
			System.out.println("Derni�re hospitalisation: n�: "+hospi.getNumPatient()+"\n Date d'entr�e: "+hospi.getDateEntree()+"\n Date de sortie: "+hospi.getDateSortie());
			
			DAO<Cim10> c = new Cim10DAO();
			Cim10 cim10 = c.find(hospi.getNumPatient());
			System.out.println("Diagnostic principal (si renseign�): \n Code CIM10: "+cim10.getCodeCim10()+"\n Libell� CIM10: "+cim10.getLibelleCim10());
		
			break;

	}
	
	// Tant que la r�ponse ne commence pas par O ou N, la console redemande � l'utilisateur
	do{System.out.println("\n Voulez-vous recommencer? Oui/Non");
			z=sc.nextLine().charAt(0);}
		
	while(z!='O' && z!='N');
		
}while(z=='O');

System.out.println("\n Bonne correction!");
sc.close();
	}
}