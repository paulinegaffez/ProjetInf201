import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Cim10DAO extends DAO<Cim10> {

    String url = "jdbc:mysql://localhost/projetInf201";
    String user = "root";
    String password = "";

    public boolean create(Cim10 c) {
        return false;
      }

      public boolean delete(Cim10 c) {
        return false;
      }       

      public boolean update(Cim10 c) {
        return false;
      }
    
      
    // Permet de r�cup�rer le code et le libell� CIM10 du diagnostic principal avec le numHospi
      
 	public Cim10 find(int numHospi) {
		Cim10 cim10 = new Cim10(); 
		
	try
    {
        Class.forName("com.mysql.jdbc.Driver").newInstance();
        Connection con = DriverManager.getConnection(url, user, password);
		
        PreparedStatement pstt = con.prepareStatement("SELECT ths_cim10.CodeCIM10, ths_cim10.LibelleCIM10\r\n" + 
        		"FROM (tab_hospitalisation INNER JOIN tab_diagnostic ON tab_hospitalisation.NumHospitalisation=tab_diagnostic.NumHospitalisation)\r\n" + 
        		"INNER JOIN ths_cim10 ON ths_cim10.CodeCIM10=tab_diagnostic.CodeCIM10\r\n" + 
        		"WHERE (tab_diagnostic.NumHospitalisation=? AND tab_diagnostic.DGType='D') AND tab_diagnostic.DGRang=1");
        pstt.setInt(1,numHospi);
        ResultSet res = pstt.executeQuery();
        if(res.first()) {
			cim10 = new Cim10(res.getString(1),res.getString(2));
		}pstt.close();
		res.close();
		con.close();
		}
		catch (SQLException e) {
		      e.printStackTrace();
		    } catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cim10;
	}   
}
